// HELLO.C

#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv)
    {
    system("CLS");
    printf("Hello world!");
    system("PAUSE");
    return 0;
    }
