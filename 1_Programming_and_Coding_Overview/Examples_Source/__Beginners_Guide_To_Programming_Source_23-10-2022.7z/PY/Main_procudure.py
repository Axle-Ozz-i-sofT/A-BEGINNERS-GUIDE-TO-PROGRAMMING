# Start Of File - Application Entry Point
# Module description
# Library includes
# Global Definitions

def main():  # Main procedure
    # Local Definitions
    # Code routines

    return None

# Function Definitions

if __name__ == '__main__':  # “Formal Entry Point”
    main()

# End Of File - Application Exit