// Start Of File - Application Entry Point
// Module description
// Library includes
// Global Definitions
// Function Definitions

int main(int argc, char *argv[])  // Main procedure – “Formal Entry Point”
    {
    // Local Definitions
    // Code routines

    return 0
    }

// End Of File - Application exit
